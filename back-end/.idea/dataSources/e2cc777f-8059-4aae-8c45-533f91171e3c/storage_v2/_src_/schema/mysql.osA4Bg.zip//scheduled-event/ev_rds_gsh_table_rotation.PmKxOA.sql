create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2021-06-11 21:00:39'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

