create definer = rdsadmin@localhost trigger block_proc_d
    before delete
    on proc
    for each row
BEGIN
DECLARE foo varchar(255);
if old.Definer = "rdsadmin@localhost" then
  select `ERROR (RDS): CANNOT DROP RDSADMIN OBJECT` into foo;
end if;
END;

