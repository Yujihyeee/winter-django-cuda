create definer = rdsadmin@localhost trigger block_event_u
    before update
    on event
    for each row
BEGIN
DECLARE foo varchar(255);
    IF old.Definer = 'rdsadmin@localhost' OR (old.Definer <> 'rdsadmin@localhost' AND new.Definer = 'rdsadmin@localhost') THEN
        select `ERROR (RDS): CANNOT MODIFY RDSADMIN OBJECT` into foo;
    END IF;
END;

