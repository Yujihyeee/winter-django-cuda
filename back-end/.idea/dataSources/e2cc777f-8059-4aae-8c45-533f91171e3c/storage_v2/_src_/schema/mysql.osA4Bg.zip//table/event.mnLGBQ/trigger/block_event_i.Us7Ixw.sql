create definer = rdsadmin@localhost trigger block_event_i
    before insert
    on event
    for each row
BEGIN
DECLARE foo varchar(255);
    IF new.Definer = 'rdsadmin@localhost' THEN
        select `ERROR (RDS): CANNOT CREATE RDSADMIN OBJECT` into foo;
    END IF;
END;

