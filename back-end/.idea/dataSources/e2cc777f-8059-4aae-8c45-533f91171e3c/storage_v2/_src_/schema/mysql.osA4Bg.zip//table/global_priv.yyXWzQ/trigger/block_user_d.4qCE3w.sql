create definer = rdsadmin@localhost trigger block_user_d
    before delete
    on global_priv
    for each row
BEGIN
DECLARE foo varchar(255);
if old.User = "rdsadmin" and old.Host = "localhost" then
  select `ERROR (RDS): CANNOT DROP RDSADMIN USER` into foo;
end if;
if old.User = "rdsrepladmin" then
  select `ERROR (RDS): CANNOT DROP RDSREPLADMIN USER` into foo;
end if;
END;

