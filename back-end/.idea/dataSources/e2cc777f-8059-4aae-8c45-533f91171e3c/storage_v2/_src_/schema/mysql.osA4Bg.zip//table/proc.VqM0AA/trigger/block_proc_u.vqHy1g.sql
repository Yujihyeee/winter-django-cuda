create definer = rdsadmin@localhost trigger block_proc_u
    before update
    on proc
    for each row
BEGIN
DECLARE foo varchar(255);
if old.Definer = 'rdsadmin@localhost' or (old.Definer <> 'rdsadmin@localhost' and new.Definer = 'rdsadmin@localhost') then
  select `ERROR (RDS): CANNOT MODIFY RDSADMIN OBJECT` into foo;
end if;
END;

