create definer = rdsadmin@localhost trigger block_user_u
    before update
    on global_priv
    for each row
BEGIN
  DECLARE foo varchar(255);
  if old.User = "rdsadmin" then
    select `ERROR (RDS): CANNOT UPDATE RDSADMIN USER` into foo from mysql.user;
  end if;

  if old.User = "rdsrepladmin" then
    select `ERROR (RDS): CANNOT UPDATE RDSREPLADMIN USER` into foo from mysql.user;
  end if;

   if (json_value(`new`.`Priv`, '$.access') & 32768) then
     select `ERROR (RDS): SUPER PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif (json_value(`new`.`Priv`, '$.access') & 128) then
     select `ERROR (RDS): SHUTDOWN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED. PLEASE USE RDS API` into foo from mysql.user;
   elseif (json_value(`new`.`Priv`, '$.access') & 512) then
     select `ERROR (RDS): FILE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif (json_value(`new`.`Priv`, '$.access') & 524288) then
     select `ERROR (RDS): REPLICA SLAVE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif (json_value(`new`.`Priv`, '$.access') & 1048576) then 
   	 select `ERROR (RDS): REPLICA CLIENT PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
  end if; 
END;

